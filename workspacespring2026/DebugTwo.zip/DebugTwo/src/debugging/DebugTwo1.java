package debugging;
public class DebugTwo1 {
	
   public void chars() {
      int oneInt = 315;
      double oneDouble = 12.4;
      char oneChar = 'A';
      System.out.println("The int is ");
      System.out.println(oneInt);
      System.out.println("The double is ");
      System.out.println(oneDouble);
      System.out.println("The char is ");
      System.out.println(oneChar);
      
   }
}