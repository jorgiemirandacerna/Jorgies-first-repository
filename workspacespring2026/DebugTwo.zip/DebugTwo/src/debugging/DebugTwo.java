package debugging;

public class DebugTwo {

public static void main(String[] args) {
	
	DebugTwo1 chars = new DebugTwo1();
	chars.chars();
	DebugTwo2 functions = new DebugTwo2();
    functions.functions();
    DebugTwo3 division = new DebugTwo3();
    division.division();
    DebugTwo4 option = new DebugTwo4();
    option.option();
}

}