package debugging;
public class DebugTwo2 {
public  void functions()
{
   {
      int a=7, b=4;
      int difference = a-b;
      System.out.println("The sum is " + a + b);
      System.out.println("The difference is " + difference);
      System.out.println("The product is " + a * b);
   }
}
}