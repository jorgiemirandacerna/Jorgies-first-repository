//Miranda Cerna 1/26 ch 1 in class 2
public class MovieQuoteInfo {

	public static void main(String[]args) {
		System.out.println("I always come back");
		System.out.println("Five Nights at Freddy's");
		System.out.println("William Afton");
		System.out.println("Year 2023");
	}
}
