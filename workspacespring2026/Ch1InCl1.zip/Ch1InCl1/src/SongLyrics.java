//Miranda Cerna 1/26 ch 1 in class 1
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("We're out here drippin' in finesse");
		System.out.println("It don't make no sense");
		System.out.println("Out here drippin' in finesse");
		System.out.println("You know it, you know it");
	}
}
